package hu.blu3berry.avalon.model.network


data class Settings(
    var assassin: Boolean,
    var mordred: Boolean,
    var morgana: Boolean,
    var oberon: Boolean,
    var percival: Boolean,
    var arnold: Boolean,
)
