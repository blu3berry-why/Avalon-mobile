package hu.blu3berry.avalon.model.network

data class LobbyCode(
    val lobbyCode: String
)
