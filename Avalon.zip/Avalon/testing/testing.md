#Testing the app:

First of all, please visit this page:

> https://ktor-avalon-rest.herokuapp.com/

This is for waking up the server on heroku, wait until the page loads and than you can log in to the app or register.

For the next step we need to create a lobby or join an existing one. I suggest creating one first because the first person to join a lobby is the one creating it and they will be the first to select people for the adventure.

Because using 5 phones or emulators to be able to start a game is inconvenient, I made a python script `main.py` which has 5 dummy users you can join with, and vote.
