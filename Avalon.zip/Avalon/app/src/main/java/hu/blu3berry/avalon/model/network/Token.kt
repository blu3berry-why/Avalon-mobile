package hu.blu3berry.avalon.model.network

data class Token(
    var username: String,
    var token: String
)
