package com.example.model.enums

enum class WINNER {
    NOT_DECIDED, EVIL, GOOD
}