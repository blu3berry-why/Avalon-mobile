package com.example.model.enums

enum class SCORE {
    EVIL, GOOD, UNDECIDED
}