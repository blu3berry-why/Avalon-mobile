package hu.blu3berry.avalon.model.network




data class AssassinGuess(
    val guess: String,
)
