package hu.blu3berry.avalon.model.network


data class SingleVote(
    val username: String,
    val uservote: Boolean,
)
