package hu.blu3berry.avalon.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING;
}